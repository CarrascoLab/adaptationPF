## Figure 2





library(dplyr)
library(ggplot2)
library(scales)
library(tidyr)


summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  library(plyr)
  
  # New version of length which can handle NA's: if na.rm==T, don't count them
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x))
    else       length(x)
  }
  
  # This does the summary. For each group's data frame, return a vector with
  # N, mean, and sd
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm)
                   )
                 },
                 measurevar
  )
  
  # Rename the "mean" column    
  datac <- rename(datac, c("mean" = measurevar))
  
  datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
  
  # Confidence interval multiplier for standard error
  # Calculate t-statistic for confidence interval: 
  # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  
  return(datac)
}
##


get_wraper <- function(width) {
  function(x) {
    lapply(strwrap(x, width = width, simplify = FALSE), paste, collapse="\n")
  }
}





## combining all data

### the horizontal reference



dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/DT_Fovea_hori_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/HL_Fovea_hori_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/JY_Fovea_hori_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MD_Fovea_hori_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MH_Fovea_hori_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MP_Fovea_hori_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/QY_Fovea_hori_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/FH_Fovea_hori_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ZL_Fovea_hori_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/RC_Fovea_hori_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ET_Fovea_hori_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SP_Fovea_hori_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SL_Fovea_hori_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ID_Fovea_hori_threshold.csv",h=F)




dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"JY"
dat4$subject<-"MD"
dat5$subject<-"MH"
dat6$subject<-"MP"
dat7$subject<-"QY"
dat8$subject<-"FH"
dat9$subject<-"ZL"
dat10$subject<-"RC"
dat11$subject<-"ET"
dat12$subject<-"SP"
dat13$subject<-"SL"
dat14$subject<-"ID"


dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)



names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+subject,data=dat,mean)
m<-aov(threshold~adapt+Error(subject/(adapt)),data=df)
summary(m)

dffovea=df

df$location="fovea"
df=df %>% relocate(adapt,location, subject,threshold)
dffovea=df






#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/DT_periphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/HL_periphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SL_periphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MP_periphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ZL_periphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MD_periphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ET_periphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/QY_periphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ID_periphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SP_periphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/FH_periphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MH_periphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/RC_periphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/JY_periphery_threshold.csv",h=F)



dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"SL"
dat4$subject<-"MP"
dat5$subject<-"ZL"
dat6$subject<-"MD"
dat7$subject<-"ET"
dat8$subject<-"QY"
dat9$subject<-"ID"
dat10$subject<-"SP"
dat11$subject<-"FH"
dat12$subject<-"MH"
dat13$subject<-"RC"
dat14$subject<-"JY"



dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)
#dat<-rbind(dat1,dat2,dat4,dat6,dat8,dat12,dat14,dat5,dat11,dat13,dat7)



names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)





levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)



#df<-aggregate(threshold~adapt+subject+location2,data=df,mean)
#df=df %>% relocate(adapt, subject,threshold,location)



df=rbind(dffovea,df)
df$location=as.factor(df$location)

#df$reference="horizontal"
#dfhori=df




model=aov(threshold~adapt*location+Error(subject/(adapt*location)),data=df)
summary(model)

df$location<-factor(df$location,levels=c("fovea","left","right","up","down"))

levels(df$location)[levels(df$location)=="up"] <- "upper"
levels(df$location)[levels(df$location)=="down"] <- "lower"




#fovea=subset(df,df$location2=="fovea")
#peri=subset(df,df$location2=="periphery")


#fadapt=fovea[fovea$adapt=="adapt",]$threshold-fovea[fovea$adapt=="non-adapt",]$threshold
#padapt=peri[peri$adapt=="adapt",]$threshold-peri[peri$adapt=="non-adapt",]$threshold

#t.test(fadapt,padapt,paired=T)

#(mean(fadapt)-mean(padapt))/sd(fadapt-padapt)


library(ggplot2)
theme_set(
  theme_classic() +
    theme(legend.position = "top")
)





df<-df[order(df$subject),]


#individualmean=aggregate(threshold~subject,data=df,mean)
#grandmean=mean(individualmean$threshold)

#minus=rep(individualmean$threshold,each=10)

#df$minus=minus
#df$grandmean=grandmean


#df$correction=df$threshold-df$minus+df$grandmean



tgct <- summarySE(df, measurevar="correction", groupvars=c("adapt","location"))
tgct


tgc <- summarySE(df, measurevar="threshold", groupvars=c("adapt","location"))
tgc




#tgc <- summarySE(df, measurevar="correction", groupvars=c("adapt","location"))
#tgc



# Initiate a ggplot
p <- ggplot(tgc, aes(x = location, y = threshold, color=adapt))
#p + stat_summary(fun.data = "mean_se", fun.args = list(mult=1))+

p+geom_point(size=6)+
  geom_errorbar(aes(ymin=threshold-se, ymax=threshold+se), width=.7, position=position_dodge(0))+
  
  
  scale_color_manual(values=c("#0F8B59","#0000CC"))+
  #coord_trans(y = "log10")+
  #scale_y_continuous(limits = c(0,65))+
  
  scale_y_log10(limits=c(1,85),breaks = breaks_log(n=6))+
  
  
  theme_bw()+
  theme(axis.ticks.length=unit(.5, "cm"))+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=35),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(15, 10, 15, 10)))+
  theme(axis.title.y.left = element_text(margin = margin(15, 10, 15, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_vline(xintercept=1.5, linetype="dashed", 
             color = "black", size=1.5)


ggsave("horizontal_fovea.tiff", path = '/Users/hsinghaolee/Desktop/', width = 10, height = 7.5,units='in')










# the vertical reference


dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/DT_Fovea_vertical_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/HL_Fovea_vertical_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/JY_Fovea_vertical_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MD_Fovea_vertical_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MH_Fovea_vertical_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MP_Fovea_vertical_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/QY_Fovea_vertical_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/FH_Fovea_vertical_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ZL_Fovea_vertical_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/RC_Fovea_vertical_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ET_Fovea_vertical_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SP_Fovea_vertical_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SL_Fovea_vertical_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ID_Fovea_vertical_threshold.csv",h=F)


dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"JY"
dat4$subject<-"MD"
dat5$subject<-"MH"
dat6$subject<-"MP"
dat7$subject<-"QY"
dat8$subject<-"FH"
dat9$subject<-"ZL"
dat10$subject<-"RC"
dat11$subject<-"ET"
dat12$subject<-"SP"
dat13$subject<-"SL"
dat14$subject<-"ID"

dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)




names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+subject,data=dat,mean)
m<-aov(threshold~adapt+Error(subject/(adapt)),data=df)
summary(m)


dffovea=df

df$location="fovea"
df=df %>% relocate(adapt,location, subject,threshold)
dffovea2=df




#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/HL_Verticalperiphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/DT_Verticalperiphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MD_Verticalperiphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SP_Verticalperiphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/RC_Verticalperiphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/JY_Verticalperiphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/QY_Verticalperiphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MH_Verticalperiphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/FH_Verticalperiphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ET_Verticalperiphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SL_Verticalperiphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MP_Verticalperiphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ZL_Verticalperiphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ID_Verticalperiphery_threshold.csv",h=F)


dat1$subject<-"HL"
dat2$subject<-"DT"
dat3$subject<-"MD"
dat4$subject<-"SP"
dat5$subject<-"RC"
dat6$subject<-"JY"
dat7$subject<-"QY"
dat8$subject<-"MH"
dat9$subject<-"FH"
dat10$subject<-"ET"
dat11$subject<-"SL"
dat12$subject<-"MP"
dat13$subject<-"ZL"
dat14$subject<-"ID"



dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)
#dat=rbind(dat1,dat2,dat3,dat6,dat7,dat8,dat12,dat5,dat9,dat10,dat13)

names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)

df2=df

#df2$location2="periphery"
#df2=aggregate(threshold~adapt+subject+location2,data=df2,mean)

#dffovea$location2="fovea"
#dffovea=dffovea[,-2]
#dffovea=dffovea %>% relocate(adapt,subject, threshold,location2)


df=rbind(dffovea2,df2)


model=aov(threshold~adapt*location+Error(subject/(adapt*location)),data=df)
summary(model)












df$reference="vertical"
dfv=df

df$location<-factor(df$location,levels=c("fovea","left","right","up","down"))


library(ggplot2)
theme_set(
  theme_classic() +
    theme(legend.position = "top")
)

levels(df$location)[levels(df$location)=="up"] <- "upper"
levels(df$location)[levels(df$location)=="down"] <- "lower"




tgc <- summarySE(df, measurevar="threshold", groupvars=c("adapt","location"))
tgc


library(ggplot2)
library(scales)

# Initiate a ggplot
p <- ggplot(tgc, aes(x = location, y = threshold, color=adapt))
#p + stat_summary(fun.data = "mean_se", fun.args = list(mult=1))+

p+geom_point(size=6)+
  geom_errorbar(aes(ymin=threshold-se, ymax=threshold+se), width=.7, position=position_dodge(0))+
  
  
  scale_color_manual(values=c("#0F8B59","#0000CC"))+
  scale_y_log10(limits=c(1,85),breaks = breaks_log(n=6))+
  
  theme_bw()+
  theme(axis.ticks.length=unit(.5, "cm"))+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=35),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(15, 10, 15, 10)))+
  theme(axis.title.y.left = element_text(margin = margin(15, 10, 15, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_vline(xintercept=1.5, linetype="dashed", 
             color = "black", size=1.5)





ggsave("vertical_fovea.tiff", path = '/Users/hsinghaolee/Desktop/', width = 10, height = 7.5,units='in')







