### Figure 3





#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/DT_periphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/HL_periphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SL_periphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MP_periphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ZL_periphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MD_periphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ET_periphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/QY_periphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ID_periphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SP_periphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/FH_periphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MH_periphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/RC_periphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/JY_periphery_threshold.csv",h=F)



dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"SL"
dat4$subject<-"MP"
dat5$subject<-"ZL"
dat6$subject<-"MD"
dat7$subject<-"ET"
dat8$subject<-"QY"
dat9$subject<-"ID"
dat10$subject<-"SP"
dat11$subject<-"FH"
dat12$subject<-"MH"
dat13$subject<-"RC"
dat14$subject<-"JY"



dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)
#dat<-rbind(dat1,dat2,dat4,dat5,dat6,dat7,dat8,dat9,dat10)
#dat<-rbind(dat1,dat2)


names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)







library(ggplot2)
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  library(plyr)
  
  # New version of length which can handle NA's: if na.rm==T, don't count them
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x))
    else       length(x)
  }
  
  # This does the summary. For each group's data frame, return a vector with
  # N, mean, and sd
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm)
                   )
                 },
                 measurevar
  )
  
  # Rename the "mean" column    
  datac <- rename(datac, c("mean" = measurevar))
  
  datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
  
  # Confidence interval multiplier for standard error
  # Calculate t-statistic for confidence interval: 
  # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  
  return(datac)
}
##





adapt<-subset(dat,dat$adapt=="adapt")
nonadapt<-subset(dat,dat$adapt=="non-adapt")

result=cbind(adapt,nonadapt[,c(1,4)])

result$adaptationeffect=result[,4] - result[,7]



result$ratio= (result[,4]-result[,7])/result[,7]
result$ratiosimple= (result[,4]/result[,7])
result$ratiosum=(result[,4]-result[,7])/(result[,4]+result[,7])





# ratio

rightadapt=subset(result,result$location=="right")
upadapt=subset(result,result$location=="up")
leftadapt=subset(result,result$location=="left")
downadapt=subset(result,result$location=="down")


rightadapt=rightadapt[,c(2,5,11)]
upadapt=upadapt[,c(2,5,11)]
leftadapt=leftadapt[,c(2,5,11)]
downadapt=downadapt[,c(2,5,11)]





names(rightadapt)=c("location","subject","rightadapt")
names(upadapt)=c("location","subject","upadapt")
names(leftadapt)=c("location","subject","leftadapt")
names(downadapt)=c("location","subject","downadapt")




#####################

horizontal=cbind(leftadapt,rightadapt[3])
vertical=cbind(upadapt,downadapt[3])
horizontal$hadapt=(horizontal$leftadapt+horizontal$rightadapt)/2
vertical$vadapt=(vertical$upadapt+vertical$downadapt)/2

df=cbind(horizontal[,c(2,5)],vertical[5])





dft=cbind(rightadapt,leftadapt[3])
names(dft)=c("location","subject","rightadapt","leftadapt")






a=mean(df$hadapt)
b=mean(df$vadapt)
subjectnumber=14

x_se=2*sd(df$hadapt)/sqrt(subjectnumber)
y_se=2*sd(df$vadapt)/sqrt(subjectnumber)



t.test(df$hadapt,df$vadapt,paired=T)


library(ggplot2)

ggplot(df, aes(x=hadapt, y=vadapt)) + 
  geom_point(size= 9,shape=1,stroke = 3)+
  scale_x_continuous(name = "horizontal meridian", limits = c(-0.2,1)) +
  scale_y_continuous(name = "vertical meridian", limits = c(-0.2,1)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=48),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(30, 0, 30, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_point(aes(x=a,y=b),colour="red",size=5,shape=9)+
  geom_abline(linewidth=0.75)+
  geom_segment(aes(x = a, y = b-y_se, xend = a, yend = b+y_se),linewidth=1.5,color="#FF6666")+ # adding y se
  geom_segment(aes(x = a-x_se, y = b, xend = a+x_se, yend = b),linewidth=1.5,color="#FF6666")+  # adding x se
  geom_point(aes(x=a,y=b),colour="#FF6666",size=9,shape=1,stroke = 2.6)

ggsave("VH_scatterplot_n14.tiff", path = '/Users/hsinghaolee/Desktop/', width = 11.5, height = 11.5,units='in')




######################


#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/HL_Verticalperiphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/DT_Verticalperiphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MD_Verticalperiphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SP_Verticalperiphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/RC_Verticalperiphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/JY_Verticalperiphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/QY_Verticalperiphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MH_Verticalperiphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/FH_Verticalperiphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ET_Verticalperiphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SL_Verticalperiphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MP_Verticalperiphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ZL_Verticalperiphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ID_Verticalperiphery_threshold.csv",h=F)


dat1$subject<-"HL"
dat2$subject<-"DT"
dat3$subject<-"MD"
dat4$subject<-"SP"
dat5$subject<-"RC"
dat6$subject<-"JY"
dat7$subject<-"QY"
dat8$subject<-"MH"
dat9$subject<-"FH"
dat10$subject<-"ET"
dat11$subject<-"SL"
dat12$subject<-"MP"
dat13$subject<-"ZL"
dat14$subject<-"ID"


dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)


names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)








adapt<-subset(dat,dat$adapt=="adapt")
nonadapt<-subset(dat,dat$adapt=="non-adapt")

result=cbind(adapt,nonadapt[,c(1,4)])

result$adaptationeffect=result[,4] - result[,7]



result$ratio= (result[,4]-result[,7])/result[,7]
result$ratiosimple= (result[,4]/result[,7])
result$ratiosum=(result[,4]-result[,7])/(result[,4]+result[,7])




## ratio ((adapt-nonadapt) / (adapt+nonadapt))


rightadapt=subset(result,result$location=="right")
upadapt=subset(result,result$location=="up")
leftadapt=subset(result,result$location=="left")
downadapt=subset(result,result$location=="down")

upadapt=upadapt[,c(2,5,11)]
downadapt=downadapt[,c(2,5,11)]
leftadapt=leftadapt[,c(2,5,11)]
rightadapt=rightadapt[,c(2,5,11)]


names(rightadapt)=c("location","subject","rightadapt")
names(upadapt)=c("location","subject","upadapt")
names(leftadapt)=c("location","subject","leftadapt")
names(downadapt)=c("location","subject","downadapt")


horizontal=cbind(leftadapt,rightadapt[3])
vertical=cbind(upadapt,downadapt[3])
horizontal$hadapt=(horizontal$leftadapt+horizontal$rightadapt)/2
vertical$vadapt=(vertical$upadapt+vertical$downadapt)/2





dft=cbind(downadapt,upadapt[3])
names(dft)=c("location","subject","downadapt","upadapt")


subjectnumber=14



df=cbind(horizontal[,c(2,5)],vertical[5])

a=mean(df$hadapt)
b=mean(df$vadapt)


x_se=2*sd(df$hadapt)/sqrt(subjectnumber)
y_se=2*sd(df$vadapt)/sqrt(subjectnumber)

t.test(df$hadapt,df$vadapt,paired=T)

(a-b)/sd(df$hadapt-df$vadapt)



df$group='reg'
df$group<-as.factor(df$group)

library(ggplot2)



ggplot(df, aes(x=hadapt, y=vadapt)) + 
  geom_point(size= 9,shape=1,stroke = 3)+
  scale_x_continuous(name = "horizontal meridian", limits = c(-0.2,1)) +
  scale_y_continuous(name = "vertical meridian", limits = c(-0.2,1)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=48),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(30, 0, 30, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_point(aes(x=a,y=b),colour="red",size=5,shape=9)+
  geom_abline(linewidth=0.75)+
  geom_segment(aes(x = a, y = b-y_se, xend = a, yend = b+y_se),linewidth=1.5,color="#FF6666")+ # adding y se
  geom_segment(aes(x = a-x_se, y = b, xend = a+x_se, yend = b),linewidth=1.5,color="#FF6666")+  # adding x se
  geom_point(aes(x=a,y=b),colour="#FF6666",size=9,shape=1,stroke = 2.6)



ggsave("VH_scatterplot_n14ratiosumv.tiff", path = '/Users/hsinghaolee/Desktop/', width = 11.5, height = 11.5,units='in')








##### 


library(dplyr)
library(ggplot2)
library(scales)
library(tidyr)


summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  library(plyr)
  
  # New version of length which can handle NA's: if na.rm==T, don't count them
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x))
    else       length(x)
  }
  
  # This does the summary. For each group's data frame, return a vector with
  # N, mean, and sd
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm)
                   )
                 },
                 measurevar
  )
  
  # Rename the "mean" column    
  datac <- rename(datac, c("mean" = measurevar))
  
  datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
  
  # Confidence interval multiplier for standard error
  # Calculate t-statistic for confidence interval: 
  # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  
  return(datac)
}
##


get_wraper <- function(width) {
  function(x) {
    lapply(strwrap(x, width = width, simplify = FALSE), paste, collapse="\n")
  }
}





## combining all data

### the horizontal reference



dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/DT_Fovea_hori_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/HL_Fovea_hori_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/JY_Fovea_hori_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MD_Fovea_hori_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MH_Fovea_hori_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MP_Fovea_hori_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/QY_Fovea_hori_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/FH_Fovea_hori_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ZL_Fovea_hori_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/RC_Fovea_hori_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ET_Fovea_hori_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SP_Fovea_hori_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SL_Fovea_hori_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ID_Fovea_hori_threshold.csv",h=F)




dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"JY"
dat4$subject<-"MD"
dat5$subject<-"MH"
dat6$subject<-"MP"
dat7$subject<-"QY"
dat8$subject<-"FH"
dat9$subject<-"ZL"
dat10$subject<-"RC"
dat11$subject<-"ET"
dat12$subject<-"SP"
dat13$subject<-"SL"
dat14$subject<-"ID"


dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)



names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+subject,data=dat,mean)
m<-aov(threshold~adapt+Error(subject/(adapt)),data=df)
summary(m)

dffovea=df

df$location="fovea"
df=df %>% relocate(adapt,location, subject,threshold)
df$fp='fovea'
dffovea=df






#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/DT_periphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/HL_periphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SL_periphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MP_periphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ZL_periphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MD_periphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ET_periphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/QY_periphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ID_periphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SP_periphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/FH_periphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MH_periphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/RC_periphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/JY_periphery_threshold.csv",h=F)



dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"SL"
dat4$subject<-"MP"
dat5$subject<-"ZL"
dat6$subject<-"MD"
dat7$subject<-"ET"
dat8$subject<-"QY"
dat9$subject<-"ID"
dat10$subject<-"SP"
dat11$subject<-"FH"
dat12$subject<-"MH"
dat13$subject<-"RC"
dat14$subject<-"JY"



dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)
#dat<-rbind(dat1,dat2,dat4,dat6,dat8,dat12,dat14,dat5,dat11,dat13,dat7)



names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)

df$fp='periphery'

#df<-aggregate(threshold~adapt+subject+location2,data=df,mean)
#df=df %>% relocate(adapt, subject,threshold,location)



df=rbind(dffovea,df)
df$location=as.factor(df$location)

df$fp<-as.factor(df$fp)

df=aggregate(threshold~subject+adapt+subject+fp,data=df,mean)


nonadapt=subset(df,df$adapt=="non-adapt")
adapt=subset(df,df$adapt=="adapt")

adapt$n.threshold=nonadapt$threshold

adapt$effect=(adapt$threshold-adapt$n.threshold)/(adapt$threshold+adapt$n.threshold)


subjectnumber=14


adapt=adapt[,-c(2,4,5)]

library(tidyr)

d=spread(adapt, key = fp, value = effect)





a=mean(d$periphery)
b=mean(d$fovea)


x_se=2*sd(d$periphery)/sqrt(subjectnumber)
y_se=2*sd(d$fovea)/sqrt(subjectnumber)



library(ggplot2)

ggplot(d, aes(x=periphery, y=fovea)) + 
  geom_point(size= 9,shape=1,stroke = 3)+
  scale_x_continuous(name = "periphery", limits = c(-0.2,1)) +
  scale_y_continuous(name = "fovea ", limits = c(-0.2,1)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=48),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(30, 0, 30, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_point(aes(x=a,y=b),colour="red",size=5,shape=9)+
  geom_abline(linewidth=0.75)+
  geom_segment(aes(x = a, y = b-y_se, xend = a, yend = b+y_se),linewidth=1.5,color="#FF6666")+ # adding y se
  geom_segment(aes(x = a-x_se, y = b, xend = a+x_se, yend = b),linewidth=1.5,color="#FF6666")+  # adding x se
  geom_point(aes(x=a,y=b),colour="#FF6666",size=9,shape=1,stroke = 2.6)


ggsave("fovea_H.tiff", path = '/Users/hsinghaolee/Desktop/', width = 11.5, height = 11.5,units='in')






#######





dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/DT_Fovea_vertical_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/HL_Fovea_vertical_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/JY_Fovea_vertical_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MD_Fovea_vertical_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MH_Fovea_vertical_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/MP_Fovea_vertical_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/QY_Fovea_vertical_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/FH_Fovea_vertical_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ZL_Fovea_vertical_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/RC_Fovea_vertical_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ET_Fovea_vertical_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SP_Fovea_vertical_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/SL_Fovea_vertical_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/fovea_decortical/ID_Fovea_vertical_threshold.csv",h=F)




dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"JY"
dat4$subject<-"MD"
dat5$subject<-"MH"
dat6$subject<-"MP"
dat7$subject<-"QY"
dat8$subject<-"FH"
dat9$subject<-"ZL"
dat10$subject<-"RC"
dat11$subject<-"ET"
dat12$subject<-"SP"
dat13$subject<-"SL"
dat14$subject<-"ID"


dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)



names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')





#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+subject,data=dat,mean)
m<-aov(threshold~adapt+Error(subject/(adapt)),data=df)
summary(m)

dffovea=df

df$location="fovea"
df=df %>% relocate(adapt,location, subject,threshold)
df$fp='fovea'
dffovea=df





dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/HL_Verticalperiphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/DT_Verticalperiphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MD_Verticalperiphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SP_Verticalperiphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/RC_Verticalperiphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/JY_Verticalperiphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/QY_Verticalperiphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MH_Verticalperiphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/FH_Verticalperiphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ET_Verticalperiphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SL_Verticalperiphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MP_Verticalperiphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ZL_Verticalperiphery_threshold.csv",h=F)
dat14=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ID_Verticalperiphery_threshold.csv",h=F)


dat1$subject<-"HL"
dat2$subject<-"DT"
dat3$subject<-"MD"
dat4$subject<-"SP"
dat5$subject<-"RC"
dat6$subject<-"JY"
dat7$subject<-"QY"
dat8$subject<-"MH"
dat9$subject<-"FH"
dat10$subject<-"ET"
dat11$subject<-"SL"
dat12$subject<-"MP"
dat13$subject<-"ZL"
dat14$subject<-"ID"



dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13,dat14)
#dat=rbind(dat1,dat2,dat3,dat6,dat7,dat8,dat12,dat5,dat9,dat10,dat13)

names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")




#dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)

df$fp='periphery'




df=rbind(dffovea,df)
df$location=as.factor(df$location)

df$fp<-as.factor(df$fp)

df=aggregate(threshold~subject+adapt+subject+fp,data=df,mean)


nonadapt=subset(df,df$adapt=="non-adapt")
adapt=subset(df,df$adapt=="adapt")

adapt$n.threshold=nonadapt$threshold

adapt$effect=(adapt$threshold-adapt$n.threshold)/(adapt$threshold+adapt$n.threshold)


subjectnumber=14


adapt=adapt[,-c(2,4,5)]

library(tidyr)
library(ggplot2)

d=spread(adapt, key = fp, value = effect)





a=mean(d$periphery)
b=mean(d$fovea)


x_se=2*sd(d$periphery)/sqrt(subjectnumber)
y_se=2*sd(d$fovea)/sqrt(subjectnumber)



library(ggplot2)

ggplot(d, aes(x=periphery, y=fovea)) + 
  geom_point(size= 9,shape=1,stroke = 3)+
  scale_x_continuous(name = "periphery", limits = c(-0.2,1)) +
  scale_y_continuous(name = "fovea ", limits = c(-0.2,1)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=48),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(30, 0, 30, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_point(aes(x=a,y=b),colour="red",size=5,shape=9)+
  geom_abline(linewidth=0.75)+
  geom_segment(aes(x = a, y = b-y_se, xend = a, yend = b+y_se),linewidth=1.5,color="#FF6666")+ # adding y se
  geom_segment(aes(x = a-x_se, y = b, xend = a+x_se, yend = b),linewidth=1.5,color="#FF6666")+  # adding x se
  geom_point(aes(x=a,y=b),colour="#FF6666",size=9,shape=1,stroke = 2.6)


ggsave("fovea_verticalr.tiff", path = '/Users/hsinghaolee/Desktop/', width = 11.5, height = 11.5,units='in')

