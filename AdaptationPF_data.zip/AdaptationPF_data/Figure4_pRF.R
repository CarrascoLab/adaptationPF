#### comparing the V1 surface area across drawers.

#DT
dat1=read.csv("/Users/hsinghaolee/Desktop/V1surface/ZL_V1surfaceDT.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/V1surface/DT_V1surfaceDT.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/V1surface/MP_V1surfaceDT.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/V1surface/MD_V1surfaceDT.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/V1surface/HL_V1surfaceDT.csv",h=F)





#HHL
dat1=read.csv("/Users/hsinghaolee/Desktop/V1surface/ZL_V1surfacehhl.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/V1surface/DT_V1surfacehhl.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/V1surface/MP_V1surfacehhl.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/V1surface/MD_V1surfacehhl.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/V1surface/HL_V1surfacehhl.csv",h=F)


dat=rbind(dat1,dat2,dat3,dat4,dat5)

# Brenda
da1=read.csv("/Users/hsinghaolee/Desktop/V1surface/ZL_V1surfaceBrenda.csv",h=F)
da2=read.csv("/Users/hsinghaolee/Desktop/V1surface/DT_V1surfaceBrenda.csv",h=F)
da3=read.csv("/Users/hsinghaolee/Desktop/V1surface/MP_V1surfaceBrenda.csv",h=F)
da4=read.csv("/Users/hsinghaolee/Desktop/V1surface/MD_V1surfaceBrenda.csv",h=F)
da5=read.csv("/Users/hsinghaolee/Desktop/V1surface/HL_V1surfaceBrenda.csv",h=F)


da=rbind(da1,da2,da3,da4,da5)

cor.test(dat$V1,da$V1)



dat$brenda=da$V1
names(dat)=c("HHLV1","location","BrendaV1")

dat$location<-as.factor(dat$location)



model=lm(dat$BrendaV1~dat$HHLV1)
co=coef(model)


library(plyr)
dat$location=revalue(dat$location, c( '0' = "right", '180' = "left", '90' = "up", '270' = "down"))
levels(dat$location)=c('left','right','up','down')

dat$location <- factor(c("right","left","up","down"),
                       levels = c("left","right","up","down"))




# plot
library(ggplot2)
ggplot(dat, aes(x=HHLV1, y=BrendaV1,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
 scale_y_continuous(name = "Brenda", limits = c(0, 420)) +
  scale_x_continuous(name = "DT", limits = c(0, 420)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=35),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(25, 0, 25, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept = co[[1]]  , slope =  co[[2]], color="black", linetype="dashed", size=1.5)+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000"))+ theme(legend.position="none")


ggsave("brenda.tiff", path = '/Users/hsinghaolee/Desktop/', width = 7.5, height = 7.5,units='in')





#HHL
dat1=read.csv("/Users/hsinghaolee/Desktop/V1surface/ID_V1surfacehhl.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/V1surface/MH_V1surfacehhl.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/V1surface/SP_V1surfacehhl.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/V1surface/ET_V1surfacehhl.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/V1surface/HL_V1surfacehhl.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/V1surface/MD_V1surfacehhl.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/V1surface/MP_V1surfacehhl.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/V1surface/DT_V1surfacehhl.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/V1surface/ZL_V1surfacehhl.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/V1surface/RC_V1surfacehhl.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/V1surface/JY_V1surfacehhl.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/V1surface/QY_V1surfacehhl.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/V1surface/SL_V1surfacehhl.csv",h=F)



dat=rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13)



#HHL
dat1=read.csv("/Users/hsinghaolee/Desktop/V1surface/ID_V1surfaceDT.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/V1surface/MH_V1surfaceDT.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/V1surface/SP_V1surfaceDT.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/V1surface/ET_V1surfaceDT.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/V1surface/HL_V1surfaceDT.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/V1surface/MD_V1surfaceDT.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/V1surface/MP_V1surfaceDT.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/V1surface/DT_V1surfaceDT.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/V1surface/ZL_V1surfaceDT.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/V1surface/RC_V1surfaceDT.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/V1surface/JY_V1surfaceDT.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/V1surface/QY_V1surfaceDT.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/V1surface/SL_V1surfaceDT.csv",h=F)


datDT=rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13)



cor.test(dat$V1,datDT$V1)



dat$DT=datDT$V1
names(dat)=c("HHLV1","location","DTV1")

dat$location<-as.factor(dat$location)


library(plyr)
dat$location=revalue(dat$location, c( '0' = "right", '180' = "left", '90' = "up", '270' = "down"))
levels(dat$location)=c('left','right','up','down')

dat$location <- factor(c("right","left","up","down"),
                       levels = c("left","right","up","down"))


model=lm(dat$DTV1~dat$HHLV1)
co=coef(model)


# plot
library(ggplot2)
ggplot(dat, aes(x=HHLV1, y=DTV1,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "DT", limits = c(0, 420)) +
  scale_x_continuous(name = "HHL", limits = c(0, 420)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=35),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(25, 0, 25, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept = co[[1]]  , slope =  co[[2]], color="black", linetype="dashed", size=1.5)+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000"))+ theme(legend.position="none")

ggsave("dt.tiff", path = '/Users/hsinghaolee/Desktop/', width = 7.5, height = 7.5,units='in')





dat$average=(dat$HHLV1+dat$DTV1)/2
subjectname=c("ID","MH","SP","ET","HL","MD","MP","DT","ZL","RC","JY","QY","SL")
dat$subject=rep(subjectname,each=4)

dat$subject<-as.factor(dat$subject)



library(plyr)
dat$location=revalue(dat$location, c( '0' = "right", '180' = "left", '90' = "up", '270' = "down"))
levels(dat$location)=c('left','right','up','down')

dat$location <- factor(c("right","left","up","down"),
                       levels = c("left","right","up","down"))

dat=dat[order(dat$location),] 
dat=dat[order(dat$subject, decreasing = TRUE),] 
surface=dat



left=dat[dat$location=="left",]
right=dat[dat$location=="right",]
up=dat[dat$location=="up",]
down=dat[dat$location=="down",]


left$HM=(left$average+right$average)/2
up$VM=(up$average+down$average)/2

t.test(left$HM,up$VM,paired=T)
difference=left$HM-up$VM
(mean(left$HM)-mean(up$VM))/sd(difference)


t.test(up$average,down$average,paired=T)
difference=up$average-down$average
(mean(up$average)-mean(down$average))/sd(difference)





library(ggplot2)
library(scales)
library(tidyr)
library(plyr)


summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  library(plyr)
  
  # New version of length which can handle NA's: if na.rm==T, don't count them
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x))
    else       length(x)
  }
  
  # This does the summary. For each group's data frame, return a vector with
  # N, mean, and sd
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm)
                   )
                 },
                 measurevar
  )
  
  # Rename the "mean" column    
  datac <- rename(datac, c("mean" = measurevar))
  
  datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
  
  # Confidence interval multiplier for standard error
  # Calculate t-statistic for confidence interval: 
  # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  
  return(datac)
}
##


get_wraper <- function(width) {
  function(x) {
    lapply(strwrap(x, width = width, simplify = FALSE), paste, collapse="\n")
  }
}


names(dat)[4]=c("v1")

tgc <- summarySE(dat, measurevar="v1", groupvars=c("location"))
tgc



# Initiate a ggplot
p <- ggplot(tgc, aes(x = location, y = v1, fill=location))+
  geom_bar(stat="identity", 
           position=position_dodge()) +
  geom_errorbar(aes(ymin=v1-se, ymax=v1+se), width=.4,position=position_dodge(.9))+
  scale_y_continuous(name = "V1 surface area (mm2)",limits = c(0, 300),expand = c(0,0),breaks=c(0,50,100,150,200,250,300))+
  scale_x_discrete(labels = c('left','right','upper',"lower"))+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=48),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-0.75))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.title.x.bottom = element_text(margin = margin(35, 0, 35, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.4))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.35, "cm"))+
  #expand_limits(y = 900000) +
  scale_fill_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+
  theme(legend.position="none")+

theme(plot.margin = margin(t = 15,  # Top margin
                           r = 2,  # Right margin
                           b = 2,  # Bottom margin
                           l = 2)) # Left margin
p 

ggsave("V1surface.tiff", path = '/Users/hsinghaolee/Desktop/', width = 11, height =11,units='in')



####################behavioral data




#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/DT_periphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/HL_periphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MP_periphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ZL_periphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ET_periphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SP_periphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MH_periphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/MD_periphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/RC_periphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/ID_periphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/QY_periphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/SL_periphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/JY_periphery_threshold.csv",h=F)



dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"MP"
dat4$subject<-"ZL"
dat5$subject<-"ET"
dat6$subject<-"SP"
dat7$subject<-"MH"
dat8$subject<-"MD"
dat9$subject<-"RC"
dat10$subject<-"ID"
dat11$subject<-"QY"
dat12$subject<-"SL"
dat13$subject<-"JY"


dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13)


names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)



df$reference="horizontal"
df2=df





#combine data plot
dat1=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/DT_Verticalperiphery_threshold.csv",h=F)
dat2=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/HL_Verticalperiphery_threshold.csv",h=F)
dat3=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MP_Verticalperiphery_threshold.csv",h=F)
dat4=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ZL_Verticalperiphery_threshold.csv",h=F)
dat5=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ET_Verticalperiphery_threshold.csv",h=F)
dat6=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SP_Verticalperiphery_threshold.csv",h=F)
dat7=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MH_Verticalperiphery_threshold.csv",h=F)
dat8=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/MD_Verticalperiphery_threshold.csv",h=F)
dat9=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/RC_Verticalperiphery_threshold.csv",h=F)
dat10=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/ID_Verticalperiphery_threshold.csv",h=F)
dat11=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/QY_Verticalperiphery_threshold.csv",h=F)
dat12=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/SL_Verticalperiphery_threshold.csv",h=F)
dat13=read.csv("/Users/hsinghaolee/Desktop/Adaptation_PF_analysis/6deg/verticalcontrol/JY_Verticalperiphery_threshold.csv",h=F)


dat1$subject<-"DT"
dat2$subject<-"HL"
dat3$subject<-"MP"
dat4$subject<-"ZL"
dat5$subject<-"ET"
dat6$subject<-"SP"
dat7$subject<-"MH"
dat8$subject<-"MD"
dat9$subject<-"RC"
dat10$subject<-"ID"
dat11$subject<-"QY"
dat12$subject<-"SL"
dat13$subject<-"JY"

dat<-rbind(dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8,dat9,dat10,dat11,dat12,dat13)


names(dat)<-c("adapt","location","reference","threshold","subject")

str(dat)
dat$adapt<-as.factor(dat$adapt)
dat$location<-as.factor(dat$location)
dat$subject<-as.factor(dat$subject)
dat$reference<-as.factor(dat$reference)



levels(dat$adapt) <- c("adapt",'non-adapt')
levels(dat$location) <- c("left","right","up","down")





dat$adapt<-factor(dat$adapt,levels=c("non-adapt","adapt"))



df=aggregate(threshold~adapt+location+subject,data=dat,mean)


df$reference="vertical"




m<-aov(threshold~adapt*location+Error(subject/(adapt*location)),data=df)
summary(m)


d=rbind(df,df2)
d$reference=as.factor(d$reference)


m<-aov(threshold~adapt*location*reference+Error(subject/(adapt*location*reference)),data=d)
summary(m)






nonadapt=subset(df,df$adapt=="non-adapt")
adapt=subset(df,df$adapt=="adapt")

adapt$non=nonadapt$threshold
adapt$effect= (adapt$threshold-adapt$non)/(adapt$threshold+adapt$non)
verticaleffect=adapt[,c(2,3,5,7)]



nonadapt=subset(df2,df2$adapt=="non-adapt")
adapt=subset(df2,df2$adapt=="adapt")

adapt$non=nonadapt$threshold
adapt$effect= (adapt$threshold-adapt$non)/(adapt$threshold+adapt$non)
horieffect=adapt[,c(2,3,5,7)]



verticaleffect=verticaleffect[order(verticaleffect$subject, decreasing = TRUE),] 

horieffect=horieffect[order(horieffect$subject, decreasing = TRUE),] 

surface=surface[order(surface$subject, decreasing = TRUE),] 

surface
verticaleffect
horieffect

surface=surface[,c(2,4,5)]
names(surface)=c("location","v1","subject")

cor.test(verticaleffect$effect,surface$v1)


verticaleffect$surface=surface$v1
horieffect$surface=surface$v1



suf=aggregate(surface~subject,data=verticaleffect,mean)
ada=aggregate(effect~subject,data=verticaleffect,mean)
cor.test(suf$surface,ada$effect)

HM=subset(verticaleffect,verticaleffect$location=="left"|verticaleffect$location=="right")
VM=subset(verticaleffect,verticaleffect$location=="up"|verticaleffect$location=="down")

HMsurface=aggregate(surface~subject,data=HM,mean)
VMsurface=aggregate(surface~subject,data=VM,mean)

HMeffect=aggregate(effect~subject,data=HM,mean)
VMeffect=aggregate(effect~subject,data=VM,mean)

effectD=HMeffect$effect-VMeffect$effect
surfaceD=HMsurface$surface-VMsurface$surface


cor.test(effectD,surfaceD)




suf=aggregate(surface~subject,data=horieffect,mean)
ada=aggregate(effect~subject,data=horieffect,mean)
cor.test(suf$surface,ada$effect)

plot(surfaceD,effectD)

HM=subset(horieffect,horieffect$location=="left"|horieffect$location=="right")
VM=subset(horieffect,horieffect$location=="up"|horieffect$location=="down")

HMsurface=aggregate(surface~subject,data=HM,mean)
VMsurface=aggregate(surface~subject,data=VM,mean)

HMeffect=aggregate(effect~subject,data=HM,mean)
VMeffect=aggregate(effect~subject,data=VM,mean)

effectD=HMeffect$effect-VMeffect$effect
surfaceD=HMsurface$surface-VMsurface$surface


cor.test(effectD,surfaceD)


plot(surfaceD,effectD)






######Correlate the non-adapted threshold with the V1 surface area
nonadapt=d[d$adapt=="non-adapt",]

vertical=nonadapt[nonadapt$reference=="vertical",]
horizontal=nonadapt[nonadapt$reference=="horizontal",]


vertical=vertical[order(vertical$subject),] 
horizontal=horizontal[order(horizontal$subject),] 
surface=surface[order(surface$subject),] 




cor.test(vertical$threshold,surface$v1)

cor.test(horizontal$threshold,surface$v1)



vertical$surface=surface$v1

temp1=aggregate(surface~location,dat=vertical,mean)
temp2=aggregate(threshold~location,dat=vertical,mean)

temp1=rep(temp1$surface,each=13)
temp2=rep(temp2$threshold,each=13)

vertical$groupsurface<-vertical$surface-temp1
vertical$groupeffect<-vertical$threshold-temp2



cor.test(vertical$groupsurface,vertical$groupeffect)





horizontal$surface=surface$v1

temp1=aggregate(surface~location,dat=horizontal,mean)
temp2=aggregate(threshold~location,dat=horizontal,mean)

temp1=rep(temp1$surface,each=13)
temp2=rep(temp2$threshold,each=13)

horizontal$groupsurface<-horizontal$surface-temp1
horizontal$groupeffect<-horizontal$threshold-temp2


cor.test(horizontal$groupsurface,horizontal$groupeffect)




temp1=aggregate(surface~subject,dat=vertical,mean)
temp2=aggregate(threshold~subject,dat=vertical,mean)

temp1=rep(temp1$surface,each=4)
temp2=rep(temp2$threshold,each=4)

vertical$surface_indi<-vertical$surface-temp1
vertical$indi<-vertical$threshold-temp2



cor.test(vertical$indi,vertical$surface_indi)




temp1=aggregate(surface~subject,dat=horizontal,mean)
temp2=aggregate(threshold~subject,dat=horizontal,mean)

temp1=rep(temp1$surface,each=4)
temp2=rep(temp2$threshold,each=4)

horizontal$surface_indi<-horizontal$surface-temp1
horizontal$indi<-horizontal$threshold-temp2



cor.test(horizontal$indi,horizontal$surface_indi)






##########averaging the two thresholds #####################

horizontal$thresholdv = vertical$threshold


horizontal$average=(horizontal$threshold+horizontal$thresholdv)/2

cor.test(horizontal$average,horizontal$surface)
cor.test(1/horizontal$average,horizontal$surface)



temp1=aggregate(surface~location,dat=horizontal,mean)
temp2=aggregate(average~location,dat=horizontal,mean)

temp1=rep(temp1$surface,each=13)
temp2=rep(temp2$average,each=13)

vertical$groupsurface<-horizontal$surface-temp1
vertical$groupeffect<-horizontal$average-temp2



cor.test(horizontal$groupsurface,horizontal$groupeffect)





temp1=aggregate(surface~subject,dat=horizontal,mean)
temp2=aggregate(average~subject,dat=horizontal,mean)

temp1=rep(temp1$surface,each=4)
temp2=rep(temp2$average,each=4)

vertical$surface_indi<-horizontal$surface-temp1
vertical$indi<-horizontal$average-temp2



cor.test(horizontal$indi,horizontal$surface_indi)




#######
verticaleffect

HM1=subset(verticaleffect,verticaleffect$location=="left"|verticaleffect$location=="right")
VM1=subset(verticaleffect,verticaleffect$location=="up"|verticaleffect$location=="down")

HMeffect=aggregate(effect~subject,data=HM1,mean)
VMeffect=aggregate(effect~subject,data=VM1,mean)

HMv1=aggregate(surface~subject,data=HM1,mean)
VMv1=aggregate(surface~subject,data=VM1,mean)


cor.test(HMeffect$effect,HMv1$surface)
cor.test(VMeffect$effect,VMv1$surface)


cor.test(HM1$effect,HM1$surface)
cor.test(VM1$effect,VM1$surface)






####################################


model=lm(verticaleffect$effect~verticaleffect$surface)
co=coef(model)



# plot
library(ggplot2)
ggplot(verticaleffect, aes(x=surface, y=effect,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  #scale_y_continuous(name = "adaptation effect", limits = c(-0.3,0.9), breaks = c(-0.3,0,0.3,0.6,0.9)) +
  #scale_x_continuous(name = "V1 surface area (mm2)", limits = c(0, 440), breaks = c(0,110,220,330,440)) +
  scale_y_continuous(name = "", limits = c(-0.3,0.9), breaks = c(-0.3,0,0.3,0.6,0.9)) +
  scale_x_continuous(name = "", limits = c(0, 440), breaks = c(0,110,220,330,440)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept = co[[1]] , slope =  co[[2]]   , color="black", linetype="dashed", size=1.5)+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")


ggsave("vertiR.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')








### regress the mean of each individual performance at each location

temp1=aggregate(surface~subject,dat=verticaleffect,mean)
temp2=aggregate(effect~subject,dat=verticaleffect,mean)


verticaleffect=verticaleffect[order(verticaleffect$subject),] 



temp1=rep(temp1$surface,each=4)
temp2=rep(temp2$effect,each=4)





verticaleffect$surface_indi<-verticaleffect$surface-temp1
verticaleffect$indi<-verticaleffect$effect-temp2






model=lm(verticaleffect$indi~verticaleffect$surface_indi)
co=coef(model)



cor.test(verticaleffect$indi,verticaleffect$surface_indi)



# plot
library(ggplot2)
ggplot(verticaleffect, aes(x=surface_indi, y=indi,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "", limits = c(-0.6, 0.6), breaks = c(-0.6,-0.3,0,0.3,0.6)) +
  scale_x_continuous(name = "", limits = c(-250, 250), breaks = c(-250,-125,0,125,250)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept = co[[1]]  , slope =  co[[2]], color="black", linetype="dashed", size=1.5)+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")

ggsave("vertiR_indi.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')






### regress the mean of  each location across observers


verticaleffect=verticaleffect[order(verticaleffect$location),] 

temp1=aggregate(surface~location,dat=verticaleffect,mean)
temp2=aggregate(effect~location,dat=verticaleffect,mean)

temp1=rep(temp1$surface,each=13)
temp2=rep(temp2$effect,each=13)

verticaleffect$groupsurface<-verticaleffect$surface-temp1
verticaleffect$groupeffect<-verticaleffect$effect-temp2


model=lm(verticaleffect$groupeffect~verticaleffect$groupsurface)
co=coef(model)

cor.test(verticaleffect$groupsurface,verticaleffect$groupeffect)




# plot
library(ggplot2)
ggplot(verticaleffect, aes(x=groupsurface, y=groupeffect,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "", limits = c(-0.6, 0.6), breaks = c(-0.6,-0.3,0,0.3,0.6)) +
  scale_x_continuous(name = "", limits = c(-250, 250), breaks = c(-250,-125,0,125,250)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_abline(intercept =-4.221e-19    , slope = -5.083e-04    , color="black", linetype="dashed", size=1.5)+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")

ggsave("vertiR_group.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')


##### horizontal reference




suf=aggregate(surface~subject,data=horieffect,mean)
ada=aggregate(effect~subject,data=horieffect,mean)
cor.test(suf$surface,ada$effect)



horieffect$surface=surface$v1

model=lm(horieffect$effect~horieffect$surface)
co=coef(model)



cor.test(horieffect$effect,surface$v1)


##########
horieffect

HM1=subset(horieffect,horieffect$location=="left"|horieffect$location=="right")
VM1=subset(horieffect,horieffect$location=="up"|horieffect$location=="down")

HMeffect=aggregate(effect~subject,data=HM1,mean)
VMeffect=aggregate(effect~subject,data=VM1,mean)

HMv1=aggregate(surface~subject,data=HM1,mean)
VMv1=aggregate(surface~subject,data=VM1,mean)


cor.test(HMeffect$effect,HMv1$surface)
cor.test(VMeffect$effect,VMv1$surface)


cor.test(HM1$effect,HM1$surface)
cor.test(VM1$effect,VM1$surface)






###########

# plot
library(ggplot2)
ggplot(horieffect, aes(x=surface, y=effect, color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "", limits = c(-0.3,0.9), breaks = c(-0.3,0,0.3,0.6,0.9)) +
  scale_x_continuous(name = "", limits = c(0, 440), breaks = c(0,110,220,330,440)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept = co[[1]] , slope =  co[[2]] , color="black", linetype="dashed", size=1.5)+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")

ggsave("horiR.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')






### regress the mean of each individual performance at each location

horieffect

horieffect=horieffect[order(horieffect$subject),] 


temp1=aggregate(surface~subject,dat=horieffect,mean)
temp2=aggregate(effect~subject,dat=horieffect,mean)

temp1=rep(temp1$surface,each=4)
temp2=rep(temp2$effect,each=4)

horieffect$surface_indi<-horieffect$surface-temp1
horieffect$indi<-horieffect$effect-temp2




model=lm(horieffect$indi~horieffect$surface_indi)
co=coef(model)


cor.test(horieffect$indi,horieffect$surface_indi)




# plot
library(ggplot2)
ggplot(horieffect, aes(x=surface_indi, y=indi,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "", limits = c(-0.6, 0.6), breaks = c(-0.6,-0.3,0,0.3,0.6)) +
  scale_x_continuous(name = "", limits = c(-250, 250), breaks = c(-250,-125,0,125,250)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  geom_abline(intercept =co[[1]] , slope =  co[[2]]   , color="black", linetype="dashed", size=1.5)+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")

ggsave("horiR_indi.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')






### regress the mean of  each location across observers

horieffect=horieffect[order(horieffect$location),] 

temp1=aggregate(surface~location,data=horieffect,mean)
temp2=aggregate(effect~location,data=horieffect,mean)

temp1=rep(temp1$surface,each=13)
temp2=rep(temp2$effect,each=13)

horieffect$groupsurface<-horieffect$surface-temp1
horieffect$groupeffect<-horieffect$effect-temp2




lm(horieffect$groupeffect~horieffect$groupsurface)

cor.test(horieffect$groupeffect,horieffect$groupsurface)



# plot
library(ggplot2)
ggplot(horieffect, aes(x=groupsurface, y=groupeffect,color=location)) + 
  geom_point(size= 10,alpha=0.75)+
  scale_y_continuous(name = "", limits = c(-0.6, 0.6), breaks = c(-0.6,-0.3,0,0.3,0.6)) +
  scale_x_continuous(name = "", limits = c(-250, 250), breaks = c(-250,-125,0,125,250)) +
  labs(title="")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(),text = element_text(family="Arial",size=55),panel.border = element_blank())+
  theme(axis.text.x = element_text(color="black",vjust=-1))+
  theme(axis.text.y = element_text(color="black"))+
  theme(axis.line = element_line(colour = "black"))+
  theme(axis.line=element_line(size=1.5))+
  theme(axis.title.x.bottom = element_text(margin = margin(3, 0, 3, 0)))+
  theme(axis.title.y.left = element_text(margin = margin(10, 10, 10, 10)))+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(plot.title = element_text(vjust = -0.5))+
  theme(axis.ticks.length=unit(.5, "cm"))+
  #geom_abline(intercept = 7.823e-18  , slope =  -1.344e-03    , color="black", linetype="dashed", size=1.5)+
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())+
  scale_color_manual(values=c('#00994C',"#33FF99","#000099","#CC0000","black"))+ theme(legend.position="none")

ggsave("horiR_group.tiff", path = '/Users/hsinghaolee/Desktop/', width = 12, height = 10,units='in')





